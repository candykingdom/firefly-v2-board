# Why this directory?

The firefly board is probably going to have a custom bootloader that has a
boot-wait delay while it asks for programming instructions.

