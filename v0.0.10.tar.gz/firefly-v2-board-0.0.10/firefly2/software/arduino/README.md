# Arduino specific implementations

This folder contains arduino specific implementations of the interfaces
described in the generic interfaces file. The code in here is not put through
CI and should be tested by compiling the example.ino file to validate.
