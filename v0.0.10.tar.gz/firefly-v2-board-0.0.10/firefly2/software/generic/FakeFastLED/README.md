This is the CRGB/CHSV definition from FastLED, extracted and slightly modified
to not include the rest of the FastLED library. It's used so that we can use
CRGB/CHSV in our 'generic' code and have it compile on desktop.
