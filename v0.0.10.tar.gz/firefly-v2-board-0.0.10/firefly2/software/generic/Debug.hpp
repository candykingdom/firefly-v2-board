#ifndef __DEBUG_HPP__
#define __DEBUG_HPP__

// Uncomment this line to enable debug printing.
//#define DEBUG 1

void debug_printf(const char *fmt, ...);

#endif
