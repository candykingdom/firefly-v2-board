#include "Effect.hpp"

Effect::Effect(uint8_t numLeds) : numLeds(numLeds) {}
